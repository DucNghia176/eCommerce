create PROCEDURE SP_SEARCH_USERS (
    p_fullName IN VARCHAR2,
    p_gender   IN VARCHAR2,
    p_isLock   IN NUMBER,
    p_email    IN VARCHAR2,
    p_result   OUT SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_result FOR
        SELECT ua.USER_ID,
               ua.USERNAME,
               ua.PASSWORD,
               ui.FULL_NAME,
               ua.EMAIL,
               ua.IS_LOCK,
               ui.AVATAR,
               ui.GENDER,
               ui.DATE_OF_BIRTH,
               ui.ADDRESS,
               ui.PHONE,
               ua.CREATE_AT,
               ua.UPDATE_AT,
               LISTAGG(r.ROLE_NAME, ',') WITHIN GROUP (ORDER BY r.ROLE_NAME) AS ROLES
        FROM USER_ACCOUNT ua
                 JOIN USER_PROFILE ui ON ua.USER_ID = ui.USER_ID
                 LEFT JOIN USER_ROLE ur ON ua.USER_ID = ur.USER_ID
                 LEFT JOIN ROLE r ON ur.ROLE_ID = r.ROLE_ID
        WHERE (p_fullName IS NULL OR ui.FULL_NAME LIKE '%' || p_fullName || '%')
          AND (p_gender IS NULL OR ui.GENDER = p_gender)
          AND (p_isLock IS NULL OR ua.IS_LOCK = p_isLock)
          AND (p_email IS NULL OR ua.EMAIL LIKE '%' || p_email || '%')
        GROUP BY ua.USER_ID, ua.USERNAME, ua.PASSWORD, ui.FULL_NAME, ua.EMAIL,
                 ua.IS_LOCK, ui.AVATAR, ui.GENDER, ui.DATE_OF_BIRTH,
                 ui.ADDRESS, ui.PHONE, ua.CREATE_AT, ua.UPDATE_AT
        ORDER BY ua.USER_ID;
END SP_SEARCH_USERS;
/

